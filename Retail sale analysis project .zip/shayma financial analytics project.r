
####################################import data###################################################################
library(readr)
SupermarketSaless<-read_csv("C:\\Users\\user\\Desktop\\shayma\\supermarket_sales - Sheet1.csv")
attach(SupermarketSaless)


ls(SupermarketSaless)
summary(Rating)
summary(`Unit price`)

summary(Quantity)
summary(cogs)
summary(`Unit price`)


######################################create new columns############################################################33
ls(SupermarketSaless)
SupermarketSaless$`Product line`

#tax column
Tax= Quantity*`Unit price`*0.05
SupermarketSaless=cbind(SupermarketSaless,Tax)
View(SupermarketSaless)



#total column 
Total= (Quantity*`Unit price`) +Tax
SupermarketSaless=cbind(SupermarketSaless,Total)
View(SupermarketSaless)



#net  income  column 
netincome  =Total- cogs  
SupermarketSaless=cbind(SupermarketSaless,netincome)
View(SupermarketSaless)


########################Frequency Distributions for Product line attribute  ##############################################

FreqDist<- table(SupermarketSaless$`Product line`)
cbind(FreqDist)

relative_freq <- prop.table(FreqDist)


PerDist<- relative_freq*100 

Dist_All<-cbind(FreqDist,relative_freq,PerDist) 
print(Dist_All)

write.table(Dist_All)

###################################Bar Charts and Pie Charts #####################################################

# Bar Chart- Frequency 
barplot(FreqDist,
        main="Barplot of SupermarketSaless",
        xlab="`Product line`",
        ylab="Frequency",
        col="pink",
        las=1,
        ylim=c(0,15))

# Bar Chart- Relative Frequency 
barplot(relative_freq,
        main="Barplot of SupermarketSaless",
        xlab="`Product line`",
        ylab="Relative Frequency",
        col="pink",las=1,
        ylim=c(0,0.25))

# Bar Chart- Percent Frequency 
barplot(PerDist,
        main="Barplot of SupermarketSaless",
        xlab="`Product line`",
        ylab="Percent Frequency",
        col="pink",las=1,ylim=c(0,25))



# Horizontal Bar plots
par(mfrow=c(3,1))

barplot(FreqDist,
        main=" FreqDist Barplot of  SupermarketSaless",
        ylab="`Product line`", xlab="Frequency",
        col="pink",xlim=c(0,15),
        horiz=T)

barplot(relative_freq,
        main="relative_freq Barplot of  SupermarketSaless", 
        ylab="`Product line`", xlab="Relative Frequency",
        col="pink",xlim=c(0,0.25),horiz=T)

barplot(PerDist,
        main="PerDist Barplot of SupermarketSaless", 
        ylab="`Product line`", xlab="Percent Frequency",
        col="pink",xlim=c(0,25),horiz=T)



barplot(FreqDist,
        main="Barplot of SupermarketSaless",
        xlab="`Product line`",
        ylab="Frequency",
        col="pink",
        las=1,
        ylim=c(0,15))

# 2D Pie Chart

pct<-c(PerDist) 

pie(FreqDist,
    main="2D Pie Chart of  SupermarketSaless", 
    labels = paste(levels(SupermarketSaless$`Product line`), 
                   sep = " ",pct,"%" ))



# 3D Pie Chart


library(plotrix) 


pie3D(FreqDist,
      main="3D Pie Chart  SupermarketSaless",
      labels = paste(levels(`Product line`), 
                     sep = " ",pct,"%" ),
      labelcex=0.7,
      theta = pi/4)



#############################Frequency Distributions for Unit price attribute ####################################

ls(SupermarketSaless)
SupermarketSaless$`Unit price`
l<- length(`Unit price`) 
x<- min(`Unit price`) 
y<- max(`Unit price`) 
R<- y-x 
k<- 9
w<- ceiling(R/k)




breaks<-seq(13.5,110.5,10)

print(breaks)

boundaries<-cut(`Unit price`,breaks)
print(boundaries)

freqdist<- table(boundaries)
print(freqdist)

dist1<- cbind(freqdist)
print(dist1)

Reldist<- freqdist/length(`Unit price`)
print(Reldist)

Perdist<- Reldist*100
print(Perdist)

FreqTable<- cbind(freqdist,Reldist, Perdist)
print(FreqTable)

write.table(FreqTable)


##############################Cumulative frequency distributions############################################

cumfreq = cumsum(freqdist) 
print(cumfreq)


table<- transform(cumfreq) 
print(table)



cumrelfreq<- cumfreq /length(`Unit price`)
print(cumrelfreq)

cumperfreq<- cumrelfreq*100
print(cumperfreq)

Tabe_Cum<- cbind(cumfreq,cumrelfreq,cumperfreq)
print(Tabe_Cum)

write.table(Tabe_Cum)


########################################Visualizing ##################################################


########################################Histogram#####################################################
par(mfrow=c(1,2))


hist(`Unit price`,
     col="lightblue",
     las=1, 
     main="Frequency Histogram",
     xlab="Unit price",
     ylim=c(0,10))

#create the frequency histogram according to 
#our choice for the classes:



hist(`Unit price`,
     breaks =breaks,
     col="lightblue",las=1, 
     main="Frequency Histogram",
     xlab="Unit price",
     xaxt = "n",
     ylim=c(0,10))

# Converting the breaks to categorical data
labels<- as.factor(breaks)

### Define x-axis scale manually ####tf
axis(1, at = breaks,labels = labels)




abline(v = mean(`Unit price`),
       col="blue",
       lwd=3,
       lty=1)




mean(`Unit price`)#to wright it inside   the plot 
mtext("Mean = 61.56",side=3,adj=0.45)


#Create the Relative Frequency histogram

breaks<-seq(13.5,110.5,10)


library(lattice)

histogram(`Unit price`,
          type="count",  
          breaks=breaks,
          col=4,
          las=1, 
          main="Histogram of Unit price",
          xlab="Unit price",
          ylab="Frequency",
          ylim=c(0,10))



require(HistogramTools)

PlotRelativeFrequency(hist(`Unit price`,breaks=breaks,plot=F),
                      col="lightblue",
                      las=1, #rotation of y axis values
                      main="Relative Frequency Histogram",
                      xlab="`Unit price`",
                      ylab="Relative Frequency",
                      xaxt = "n",
                      ylim=c(0,0.2))


axis(1, at = breaks,labels = labels)#Define x-axis scale manually 



library(lattice)

histogram(`Unit price`,
          type="percent",
          col="lightblue",
          breaks=breaks,
          las=1, 
          main="Histogram of Unit price",
          xlab="Unit price",
          ylab="Percent Frequency",
          ylim=c(0,20))


#############################################Dot plot#####################################################

stripchart(`Unit price`,
           method="stack", 
           at=0.05, 
           frame.plot = FALSE, 
           cex=1,
           pch=8, 
           xlim=c(0,100), 
           main="Dot Plot For SupermarketSaless dataset ")

text(55,0.8," SupermarketSaless(`Unit price`)")


################################################ Crosstabulation 1  #########################################################

###Crosstabulation of payment and unit price data



breaks<-seq(13.5,103.5,10)
print(breaks)

boundaries <-cut(`Unit price`,breaks) # transform to categorical variable
print(boundaries)

#Create Contingency table 
SupermarketSaless$Payment

# factor command is used to change the alphabetical order (R default) for categories 
Crosstab<-table(factor(Payment,levels=c("Cash","Credit card","Ewallet"))
                ,boundaries)
print(Crosstab)
write.table(Crosstab)


# If desired, can get the marginal frequencies 
R_Total<-margin.table(Crosstab,1) 
print(R_Total)

summary(`Unit price`)
apply(Crosstab,1,sum)

# Column marginal frequencies,
C_Total<- table(boundaries)
apply(Crosstab,2,sum)
print(C_Total)



R_Percent<-round(100*R_Total/length(`Unit price`),2) # Row marginal Percent frequencies
print(R_Percent)
C_Percent<- round(100*C_Total/length(`Unit price`),2) # Column marginal Percent frequencies
print(C_Percent)




#Get Cell, Row, and Column %
Cellper<- round(prop.table(Crosstab),3) *100 # Cell % joint prob
print(Cellper)


#Row percentages for each payment method 
Rowper<- round(prop.table(Crosstab,1),3)*100 
print(Rowper)


#Column percentage for each payment method
Columnper<- round(prop.table(Crosstab,2),3)*100 
print(Columnper)



##################################################### bar chart  ###################################################


Crosstab<-table(factor(Payment,levels=c("Cash","Credit card","Ewallet"))
                ,boundaries)

# side-by-side frequency bar chart

barplot(Crosstab,
        beside=T,
        col=c("pink","blue","lightblue"),
        legend.text = T, 
        xlab="`Unit price`", 
        ylab="Frequency",
        ylim=c(0,6),las=1)

# Stacked frequency bar chart

barplot(Crosstab,beside=F,
        col=c("pink","blue","lightblue"),
        legend.text = T, 
        xlab="`Unit price`($)", 
        ylab="Frequency",
        ylim=c(0,10),las=1)



# Stacked column percentages bar chart

column_percentages<-round(prop.table(Crosstab,2),3)*100 #Column %
barplot(column_percentages,
        beside=F,
        col=c("pink","blue","lightblue"),
        legend.text = F, 
        xlab="`Unit price`($)", 
        ylab="Percentage frequencies",
        ylim=c(0,100))

legend("top",inset=-0.15,  
       legend=c("Cash","Credit card","Ewallet"), 
       col=c("pink","blue","lightblue"),
       pch=15,xpd=T, horiz=T,
       bty="n")



#################################### Scatter Diagram and Trend line ###################################



ls(SupermarketSaless)
SupermarketSaless$Total
plot(SupermarketSaless$cogs,
     SupermarketSaless$Quantity, 
     ylab="Quantity",
     xlab="cogs",
     col="lightblue",
     pch=3, 
     ylim=c(1,30) ,las=3)

# create regression line
abline(lmSupermarketSaless$cogs~SupermarketSaless$Quantity) 

# add smooth spline
lines(smooth.spline(SupermarketSaless$cogs,SupermarketSaless$Quantity)) 



################################################ Crosstabulation 2  #########################################################

###Crosstabulation of product line  and net income  data



SupermarketSaless$netincome

min (netincome)
max (netincome)
breaks<-seq(0,50,10)
print(breaks)

boundaries <-cut(netincome,breaks) # transform to categorical variable
print(boundaries)

#Create Contingency table 
SupermarketSaless$`Product line`

# factor command is used to change the alphabetical order (R default) for categories 
Crosstab<-table(factor(`Product line`,levels=c("Health and beauty","Electronic accessories","Home and lifestyle","Sports and travel","Fashion accessories","Food and beverages") )
                ,boundaries)
print(Crosstab)
write.table(Crosstab)


# If desired, can get the marginal frequencies 
R_Total<-margin.table(Crosstab,1) 
print(R_Total)

summary(netincome)
apply(Crosstab,1,sum)

# Column marginal frequencies,
C_Total<- table(boundaries)
apply(Crosstab,2,sum)
print(C_Total)



R_Percent<-round(100*R_Total/length(netincome),2) # Row marginal Percent frequencies
print(R_Percent)
C_Percent<- round(100*C_Total/length(netincome),2) # Column marginal Percent frequencies
print(C_Percent)




#Get Cell, Row, and Column %
Cellper<- round(prop.table(Crosstab),3) *100 # Cell % joint prob
print(Cellper)


#Row percentages for each payment method 
Rowper<- round(prop.table(Crosstab,1),3)*100 
print(Rowper)


#Column percentage for each payment method
Columnper<- round(prop.table(Crosstab,2),3)*100 
print(Columnper)


















